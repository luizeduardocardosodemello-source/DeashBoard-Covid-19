"""
Template de ETL do projeto: Impacto da COVID-19 nos indicadores socioeconomicos.
Fluxo: extrair (API Banco Mundial) -> limpar/transformar (Pandas) -> CSV -> MongoDB.
Cada integrante troca apenas o dicionario INDICADORES e roda o script.

Requisitos: pip install pandas requests pymongo
"""
import os
import pandas as pd
import requests
from pymongo import MongoClient, UpdateOne

# ---------- Configuracao comum (nao alterar sem combinar com a equipe) ----------
PAISES = {"BRA": "Brasil", "USA": "Estados Unidos", "CHN": "China",
          "DEU": "Alemanha", "IND": "India"}
ANO_INI, ANO_FIM = 2019, 2023
PASTA_CSV = "data/processed"
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB, MONGO_COL = "covid_socioeconomico", "indicadores"

# ---------- Cada integrante edita aqui os seus indicadores ----------
# chave = codigo do Banco Mundial; valor = (nome padronizado, unidade)
INDICADORES = {
    "NY.GDP.MKTP.KD.ZG": ("Crescimento do PIB", "%"),
    "SL.UEM.TOTL.ZS": ("Desemprego", "%"),
    "FP.CPI.TOTL.ZG": ("Inflacao", "%"),
    "SP.DYN.LE00.IN": ("Expectativa de vida", "anos"),
}


def extrair(codigo: str) -> pd.DataFrame:
    """Baixa um indicador para os 5 paises e o periodo definido."""
    url = (f"https://api.worldbank.org/v2/country/{';'.join(PAISES)}"
           f"/indicator/{codigo}")
    params = {"date": f"{ANO_INI}:{ANO_FIM}", "format": "json", "per_page": 500}
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    corpo = r.json()
    if len(corpo) < 2 or corpo[1] is None:
        raise ValueError(f"Sem dados para {codigo}")
    return pd.DataFrame(corpo[1])


def transformar(bruto: pd.DataFrame, nome: str, unidade: str) -> pd.DataFrame:
    """Padroniza colunas, tipos e cria a fase da pandemia."""
    df = pd.DataFrame({
        "pais_iso3": bruto["countryiso3code"],
        "ano": pd.to_numeric(bruto["date"], errors="coerce"),
        "valor": pd.to_numeric(bruto["value"], errors="coerce"),
    })
    df["pais"] = df["pais_iso3"].map(PAISES)
    df["indicador"], df["unidade"] = nome, unidade
    df["fonte"] = "Banco Mundial"
    df = df.dropna(subset=["pais", "ano"])          # valor nulo e mantido (dado ausente)
    df["ano"] = df["ano"].astype(int)
    df = df.drop_duplicates(["pais_iso3", "ano", "indicador"])
    df["fase"] = pd.cut(df["ano"], [2018, 2019, 2021, 2023],
                        labels=["Antes", "Durante", "Depois"]).astype(str)
    cols = ["pais_iso3", "pais", "ano", "fase", "indicador", "valor", "unidade", "fonte"]
    return df[cols].sort_values(["pais_iso3", "ano"]).reset_index(drop=True)


def salvar_csv(df: pd.DataFrame, nome: str) -> str:
    os.makedirs(PASTA_CSV, exist_ok=True)
    caminho = os.path.join(PASTA_CSV, nome.lower().replace(" ", "_") + ".csv")
    df.to_csv(caminho, index=False, encoding="utf-8-sig")  # utf-8-sig: acentos no Power BI
    return caminho


def carregar_mongo(df: pd.DataFrame) -> int:
    """Upsert por (pais, ano, indicador): pode rodar varias vezes sem duplicar."""
    col = MongoClient(MONGO_URI)[MONGO_DB][MONGO_COL]
    ops = []
    for reg in df.where(df.notna(), None).to_dict("records"):
        chave = {k: reg[k] for k in ("pais_iso3", "ano", "indicador")}
        ops.append(UpdateOne(chave, {"$set": reg}, upsert=True))
    if ops:
        col.bulk_write(ops)
    col.create_index([("pais_iso3", 1), ("ano", 1), ("indicador", 1)], unique=True)
    return len(ops)


if __name__ == "__main__":
    for codigo, (nome, unidade) in INDICADORES.items():
        df = transformar(extrair(codigo), nome, unidade)
        csv = salvar_csv(df, nome)
        n = carregar_mongo(df)
        print(f"{nome}: {len(df)} linhas -> {csv} | {n} registros no MongoDB")
